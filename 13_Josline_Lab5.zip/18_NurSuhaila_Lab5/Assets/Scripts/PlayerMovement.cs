﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    public float speed;
    public Rigidbody playerRigidbody;
    public int score;
    public int totalCoins;
    public Text txtCoins;

    private void Start()
    {
        totalCoins = GameObject.FindGameObjectsWithTag("Coins").Length;
    }
    private void Update()
    {
        if (score == totalCoins)
        {
            SceneManager.LoadScene("Gameplay_Level2");
        }
    }

    private void FixedUpdate()
    {
        float MoveHorizontal = Input.GetAxis("Horizontal");
        float MoveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(MoveHorizontal, 0, MoveVertical);
        transform.Translate(movement * Time.deltaTime * speed);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Coins")
        {
            score++;
            txtCoins.text = "Coins Collected: " + score;
            Destroy(collision.gameObject);
        }

        if (collision.gameObject.tag == "Hazards")
        {
            Destroy(this.gameObject);
            SceneManager.LoadScene("GameLose");
        }
    }

}
